'''
Created on 14 abr. 2019

@author: German
'''

from map_dataset import map_dataset

def main(args):
    return map_dataset(args)
